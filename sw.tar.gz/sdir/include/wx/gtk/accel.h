/////////////////////////////////////////////////////////////////////////////
// Name:        wx/gtk/accel.h
// Purpose:     wxAcceleratorTable redirection file
// Author:      Julian Smart
// Modified by:
// Created:
// Copyright:   (c) Julian Smart
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

// VZ: keeping the old file just in case we're going to have a native GTK+
// wxAcceleratorTable implementation one day, but for now use the generic
// version
#include "wx/generic/accel.h"
